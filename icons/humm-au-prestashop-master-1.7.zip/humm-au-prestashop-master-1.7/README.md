# humm-prestashop


https://github.com/shophumm/humm-au-prestashop/blob/master/1.7/Prestashop1.6_1.7.pdf


PrestaShop integration plugin for using the humm payment gateway

download from https://github.com/shophumm/humm-au-prestashop/archive/master/1.7.zip


extra Zip file in the PS 1.7 store in the module folder 

or use admin console->modules->module manager->upload a zip file to install

plugin and zip file name are hummprestashop

Please see https://docs.shophumm.com.au for information on how to use this plugin

